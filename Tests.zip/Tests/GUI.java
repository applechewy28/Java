import javax.swing.*;
public class GUI
{
    public static void main (String [] args){
        JOptionPane.showMessageDialog(null,"Wassup","Lol",JOptionPane.PLAIN_MESSAGE);
        
        JOptionPane.showConfirmDialog(null,"Are you high ? ","How high are you?",JOptionPane.YES_NO_CANCEL_OPTION);
        String result;
        //String result = JOptionPane.showInputDialog(null,"Question 12345","Yes",JOptionPane.QUESTION_MESSAGE);
        
        
    }
    
}