import javax.swing.JFrame;
public class UICS201 extends JFrame
{
    public UICS201(){
        setSize(600,1200);
        setLocation(420,100);
        setTitle("David Andre Ramos CS-201");
        setVisible(true);
        
    }
    public static void main (String[] args){
        new UICS201();

        
    }
}
/*Container- provides a space where a component
Swing Containers
1- JPanel is the simplest container 
2- Jframe = top level window with a title and border
3= JWindow- object is a top level window iwth no borders
JFrame = the class is an axtended version of java,awt,frame that ads asupport for the jfc/swing compoent architecture
Example
public class JFrame
    extends Frame
        implements WindowConstants, Accessible, RootPaneContainer
        
Jframe Methods
setVisible()- This method is used to control wherer a component will be displayed on the screen or not. It chooses a boolean value
setSize()- This method is used to set the size of the window displayed on the screen Ex setSize(100,200)
setLocation()-This method is used to set the window's location on the screen
setTitle-This method is used to set the title of the window.

Instanating a class
import javax.swing.*;
public class myWindow
{
    public static void main (String [] args){
        JFrame window = new JFrame();
        window.setTitle("My Window");
        window.setVisible(true);
        window.setSize(800,300);
        window.setLocation(0,0);
        
        
        
        
    }
    
}

JframeMethods
setDefaultCloseOperation()- this method is called when one clicks the clsoe button.
Ex.
JFrame.DO_NOTHING_ON_CLOSE
JFrame.HIDE_ON_CLOSE
JFrame.DISPOSE_ON_CLOSE
JFrame.EXIT_ON_CLOSE
setBounds()= set size and set location in 1 command
Layout- arrange of components inside the container.
FlowLayout - places cotnrols in succecisive row
BorderLayout- places control agaitns four frame border
CardLayout- top of each other
GridLayout- controls within a specified rectangular grid
GridBagLayout- controls with a specified very flexing rectangular grid
BoxLayout-
JLabel- display
JTextfield- input
JButton- button
 * 
 */