
import java.util.Scanner;
public class Dog
{
    // instance variables - replace the example below with your own
    public static void main (String [] args){
        int val1;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter value 1 : ");
        val1 = sc.nextInt();
        System.out.println("Enter value 2 : ");
        System.out.println ("Age is " + val1);
        
    
        

        
        
    }

    
    
    
}
