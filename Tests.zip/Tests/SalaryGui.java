import javax.swing.*;
public class SalaryGui{
    public static void main (String [] args){
        int sum,totald,net;
        

        int rate = Integer.parseInt(JOptionPane.showInputDialog(null,"Rate per day : ","Salary Computation",JOptionPane.QUESTION_MESSAGE));
        int days = Integer.parseInt(JOptionPane.showInputDialog(null,"No. of days work : ","Salary Computation",JOptionPane.QUESTION_MESSAGE));
        //Deduction
        int sss = Integer.parseInt(JOptionPane.showInputDialog(null,"SSS : ","Salary Computation",JOptionPane.QUESTION_MESSAGE));
        int pagibig = Integer.parseInt(JOptionPane.showInputDialog(null,"Pag-ibig Fund : ","Salary Computation",JOptionPane.QUESTION_MESSAGE));
        int tax = Integer.parseInt(JOptionPane.showInputDialog(null,"Withholding Tax : ","Salary Computation",JOptionPane.QUESTION_MESSAGE));
        sum = rate * days;
        totald = sss + pagibig + tax;
        net = sum - totald;
        //Output
        JOptionPane.showMessageDialog(null,"Total Deduction : "+totald +"\nGross Pay : "+ sum +"\nNet Pay : " +net ,"Salary Computation",JOptionPane.PLAIN_MESSAGE);
        
        

        
      
        
        
    }
    
}
