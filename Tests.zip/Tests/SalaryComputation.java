import java.util.*;
public class SalaryComputation {
    public static void main (String [] args){
        float rate,days,sss,pagibig,tax;
        double sum,totald,gross,net;
        Scanner sc = new Scanner(System.in);
        System.out.println("Rate per Day : ");
        rate = sc.nextFloat();
        System.out.println("No. of days work : ");
        days = sc.nextFloat();
        
        //Deduction
        System.out.println("SSS : ");
        sss = sc.nextFloat();
        System.out.println("Pag-Ibig Fund : ");
        pagibig= sc.nextFloat();
        System.out.println("Witholding Tax : ");
        tax = sc.nextFloat();
        totald = sss + pagibig + tax; 
        System.out.println("Total Deduction : "+totald);
        
        //GrossPay
        sum= rate * days; 
        System.out.println("Gross Pay : " + sum);
        net = sum -totald;
        System.out.println("Net Pay : "+net);

         
         
         
        
        
        
    
        
    }
    
}
