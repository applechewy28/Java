import java.util.*;
public class Console {
    public static void main (String [] args){
        float rate,days,SSS,pagibig,tax;
        Scanner sc = new Scanner (system
    }
    
}
